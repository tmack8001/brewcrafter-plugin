console.log('addon initated in popup');
